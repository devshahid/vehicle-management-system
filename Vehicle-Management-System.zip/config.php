<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "vehiclemanagement";
// $db = "vehicledb";
$databasekey = mysqli_connect($hostname, $username, $password, $db);
