<?php
$hostname = "localhost";
$username = "root";
$password = "";
$db = "vehiclemanagement";
$databasekey = mysqli_connect($hostname, $username, $password, $db);
