<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/navbar.css">
</head>

<body>
    <div class="dashboardContent">
        <button><a href="./addstaffdetails.php">Add Staff Details</a></button>
        <button><a href="./addbusdetails.php">Add Bus Details</a> </button>
        <button><a href="./addbusroute.php">Add Bus Route</a></button>
        <button><a href="./booktickets.php">Book Tickets</a></button>
        <button><a href="./bookinghistory.php">Booking History</a></button>
        <button><a href="./verifiedtickets.php">Verified Tickets</a></button>
        <button><a href="./staffinfo.php">Staff info</a></button>
        <button><a href="./businfo.php">Bus info</a></button>
        <button><a href="./logout.php">Log Out</a></button>
    </div>
</body>

</html>