<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admindashboard</title>
</head>

<body>
    <button><a href="./addstaffdetails.php">add staff details</a></button>
    <button><a href="./addbusdetails.php">add bus details</a> </button>
    <button><a href="./addbusroute.php">add bus route</a></button>
    <button><a href="./booktickets.php">book tickets</a></button>
    <button><a href="./bookinghistory.php">booking history</a></button>
    <button><a href="./verifiedtickets.php">verified tickets</a></button>
    <button><a href="./staffinfo.php">staff info</a></button>
    <button><a href="./businfo.php">bus info</a></button>
    <button><a href="./logout.php">Log Out</a></button>

</body>

</html>