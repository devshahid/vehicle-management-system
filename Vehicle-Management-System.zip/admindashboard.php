<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin Dashboard</title>
</head>

<body>
    <div class="adminDashboard">
        <?php require('./navbar.php') ?>
        <div class="adminBody">
            <h1>WELCOME ADMIN!!</h1>
            <p>Choose Actions</p>
        </div>
    </div>
</body>

</html>